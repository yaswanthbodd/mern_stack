const express = require('express')
const router = express.Router()
const Doctors = require('../models/doctors')

router.get('/', async(req,res) => {
    try{
            const doctors =  await Doctors.find()
            res.json(doctors)
    }catch(err){
        res.send('Error '+ err)
    }
})

router.get('/:id', async(req,res) => {
    try{
            const doctor =  await Doctor.findById(req.params.id)
            res.json(doctor)
    }catch(err){
        res.send('Error '+ err)
    }
})

router.post('/',async(req,res)=>{
    const doctors= new Doctors({
        name: req.body.name,
        age: req.body,age,
        job: req.body.sub

    })

try{
     const doc = await doctors.save()
     res.json(doc)
}catch(err){
    res.send('Error')
}
})

router.patch('/:id',async(req,res) =>{
  try{
    const doctor = await doctor.findById(req.params.id)
    doctor.sub = req.body.sub
    const doc = await doctor.save()
    res.json(doc)
  }catch(err){
     res.send('Error')
  }

})

module.exports = router